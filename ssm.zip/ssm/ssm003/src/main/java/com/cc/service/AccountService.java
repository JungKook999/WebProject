package com.cc.service;

import com.cc.pojo.Account;
import com.cc.pojo.TransactionRecord;

import java.util.Map;

public interface AccountService {
    /**
     * 查询账号是否存在
     * @param cardNo 卡号
     * @return
     */
    Boolean exitsCardNo(String cardNo);

    /**
     * 登陆验证
     * @param account 账户
     * @return
     */
    Account login(Account account);

    /**
     * 查询余额
     * @param cardNo 卡号
     * @return
     */
    double quryBalance(String cardNo);

    Map<String, Object> transfer(Account sourceAccount, String cardNo, Double transactionAmount);

    Account pwdCorrect(Account account);

    int changePwd(Account account, String newPwd1);
}
