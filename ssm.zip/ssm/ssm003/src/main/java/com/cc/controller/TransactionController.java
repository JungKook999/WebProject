package com.cc.controller;

import com.cc.pojo.TransactionRecord;
import com.cc.service.TransactionRecordService;
import com.github.pagehelper.PageInfo;
import dto.RecordDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.xml.stream.events.DTD;
import java.util.List;

@Controller
@RequestMapping("/transactionRecords")
public class TransactionController {

    @Autowired
    private TransactionRecordService transactionRecordService;

//    查询所有交易记录
    @RequestMapping("/query")
    public String queryAllByTime(RecordDTO recordDTO, Model model){

        PageInfo<TransactionRecord> page = transactionRecordService.queryByCardNo(recordDTO);
        model.addAttribute("pageInfo", page);
        model.addAttribute("page", "record");

        return "main";
    }

    @RequestMapping("/index")
    public String index(Model model){
        model.addAttribute("page", "record");

        return "main";
    }
}
