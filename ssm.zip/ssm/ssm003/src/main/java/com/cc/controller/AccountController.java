package com.cc.controller;

import com.cc.constant.StatusCodeConstent;
import com.cc.pojo.Account;
import com.cc.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.util.Map;

@Controller
@RequestMapping("/account")
public class AccountController {

    @Autowired
    private AccountService accountService;

    /**
     * 登陆
     * @param account 账户
     * @param model
     * @param session
     * @return
     */
    @RequestMapping("/login")
    public String login(Account account, Model model, HttpSession session){

//        假设验证通过
        Boolean exitsCardNo = accountService.exitsCardNo(account.getCardNo());
        if (exitsCardNo){
//            卡号密码登录
            account = accountService.login(account);
            if (account==null){
//                密码错误
                model.addAttribute("errorMsg","密码错误");
                return "index";
            }else{
//                检查状态
                if (account.getStatus()==0){
//                    冻结
                    model.addAttribute("errorMsg","账号被冻结");
                    return "index";
                }else{
//                    登陆成功
                    session.setAttribute("account",account);
                    return "main";
                }
            }
        }else {
//            卡号不存在
            model.addAttribute("errorMsg","卡号不存在");
            return "index";
        }
    }

    /**
     * 退出
     * @param session
     * @return
     */
    @RequestMapping("/logout")
    public String logout(HttpSession session){
        session.removeAttribute("account");
        session.invalidate();
        return "redirect:/";
    }

    /**
     * 查询余额
     * @param cardNo
     * @param model
     * @return
     */
    @RequestMapping("/balance/{cardNo}")
    public String queryBalance(@PathVariable("cardNo") String cardNo, Model model){
        double balance = accountService.quryBalance(cardNo);
        model.addAttribute("balance",balance);
        model.addAttribute("page","balance");
        return "main";
    }

    @RequestMapping("/transferTo")
    public String transferTo(Model model){
        model.addAttribute("page","transfer");
        return "main";
    }

    @RequestMapping("/transfer")
    public String transfer(Model model, @RequestParam("cardNo") String cardNo, @RequestParam("transactionAmount") Double transactionAmount, HttpSession session){
        Account sourceAccount = (Account) session.getAttribute("account");
        Map<String,Object> map = accountService.transfer(sourceAccount,cardNo,transactionAmount);
        int code = (int) map.get("code");
        model.addAttribute("code",code);
        String msg = (String) map.get("msg");
        model.addAttribute("msg",msg);

        model.addAttribute("page","transfer");
        return "main";
    }

    @RequestMapping("/changeTo")
    public String changeTo(Model model){
        model.addAttribute("page","change");
        return "main";
    }

    @RequestMapping("/change")
    public String change(@RequestParam("cardNo") String cardNo, @RequestParam("password")String password, @RequestParam("newPwd1")String newPwd1, @RequestParam("newPwd2")String newPwd2, Model model){
        Account account = new Account();
        account.setCardNo(cardNo);
        account.setPassword(password);
        Account a = accountService.pwdCorrect(account);
        model.addAttribute("page","change");

        if (a==null){
//            密码错误
            model.addAttribute("errorMsg","旧密码错误");
            return "main";
        }else {
//            if (newPwd1.length()!=6 || newPwd2.length()!=6){
////                密码长度不是6位
//                model.addAttribute("errorMsg","密码长度必须为6位");
//                return "main";
//            }else {
                if (!newPwd1.equals(newPwd2)){
//                两次密码不一致
                    model.addAttribute("errorMsg","两次密码不一致");
                    return "main";
                }else{
                    if (password.equals(newPwd1)){
                        model.addAttribute("errorMsg","新密码与原密码相同");
                        return "main";
                    }else{
                        // 更改密码
                        accountService.changePwd(account,newPwd1);
                        model.addAttribute("page","");
                        return "main";
                    }

                }


        }

    }
}
