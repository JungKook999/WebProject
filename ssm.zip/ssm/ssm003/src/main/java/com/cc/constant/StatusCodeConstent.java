package com.cc.constant;

/**
 *
 */
public class StatusCodeConstent {
    //    账号存在
    public static int EXISTS = 2000;

    //    账号不存在
    public static int NOT_EXISTS = 2003;
    public static String NOT_EXISTS_MSG = "账号不存在";

    //    账号冻结
    public static int FREEZON = 2103;
    public static String FREEZON_MSG = "账号被冻结";

    //    账号激活
    public static int ACTIVE = 2100;

    //    余额不足
    public static int BALANCE_NOT_ENOUGH = 2400;
    public static String BALANCE_NOT_ENOUGH_MSG = "余额不足";

    //    成功
    public static int SUCCESS = 2020;
    public static String SUCCESS_MSG = "成功";
}