package com.cc.service.Impl;

import com.cc.mapper.TransactionMapper;
import com.cc.pojo.TransactionRecord;
import com.cc.service.TransactionRecordService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import dto.RecordDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("transactionService")
public class TransactionRecordServiceImpl implements TransactionRecordService {

    @Autowired
    private TransactionMapper transactionMapper;

    /**
     * 交易记录分页查询
     * @param recordDTO
     * @return
     */
    @Override
    public PageInfo<TransactionRecord> queryByCardNo(RecordDTO recordDTO) {

        PageHelper.startPage(recordDTO.getPageNum(), recordDTO.getPageSize());
        List<TransactionRecord> l = transactionMapper.queryByCardNo(recordDTO);

        PageInfo<TransactionRecord> page = new PageInfo<>(l);
        return page;
    }
}
