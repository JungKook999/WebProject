package com.cc.mapper;

import com.cc.pojo.TransactionRecord;
import dto.RecordDTO;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

public interface TransactionMapper {
    int insert(TransactionRecord transactionRecord);

//    List<TransactionRecord> queryByCardNo(@Param("cardNo") String cardNo, @Param("start") Date start, @Param("end") Date end);
    List<TransactionRecord> queryByCardNo(RecordDTO recordDTO);
}
