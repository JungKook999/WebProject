package com.cc.service;

import com.cc.pojo.TransactionRecord;
import com.github.pagehelper.PageInfo;
import dto.RecordDTO;



public interface TransactionRecordService {
    PageInfo<TransactionRecord> queryByCardNo(RecordDTO recordDTO);
}
