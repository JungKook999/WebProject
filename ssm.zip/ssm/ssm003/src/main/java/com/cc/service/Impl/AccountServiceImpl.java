package com.cc.service.Impl;

import com.cc.constant.StatusCodeConstent;
import com.cc.mapper.AccountMapper;
import com.cc.mapper.TransactionMapper;
import com.cc.pojo.Account;
import com.cc.pojo.TransactionRecord;
import com.cc.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service("accountService")
public class AccountServiceImpl implements AccountService {

    @Autowired
    private AccountMapper accountMapper;

    @Autowired
    private TransactionMapper transactionMapper;

    /**
     * 卡号是否存在
     * @param cardNo 卡号
     * @return
     */
    @Override
    public Boolean exitsCardNo(String cardNo) {
        int count = accountMapper.exitsCardNo(cardNo);

        return count==1 ? true:false;

    }

    /**
     * 登陆
     * @param account 账户
     * @return
     */
    @Override
    public Account login(Account account) {
        Account a = accountMapper.queryByCardNoPwd(account.getCardNo(),account.getPassword());
        return a;
    }

    /**
     * 查询余额
     * @param cardNo 卡号
     * @return
     */
    @Override
    public double quryBalance(String cardNo) {
        return accountMapper.queryBalance(cardNo);
    }

    /**
     * 转账
     * @param sourceAccount
     * @param cardNo
     * @param transactionAmount
     * @return
     */
    @Override
    public Map<String, Object> transfer(Account sourceAccount, String cardNo, Double transactionAmount) {
        Map<String, Object> map = new HashMap<>();
        int code = StatusCodeConstent.NOT_EXISTS;
        String msg = null;
//          1.账号是否存在
        int row = accountMapper.exitsCardNo(cardNo);
        if (row==1){
//            目标账号存在
            code = StatusCodeConstent.EXISTS;
            //        2.账号是否被冻结
            row = accountMapper.freeZon(cardNo);
            if (row == 1){
//                激活
//               3.检查余额是否充足
                row = accountMapper.balanceEnough(sourceAccount.getCardNo() , transactionAmount);
                if (row == 1){
//                    余额充足,转账
//                    1.加钱
                    accountMapper.plusMoney(cardNo,transactionAmount);
//                    2.减钱
                    accountMapper.minusMoney(sourceAccount.getCardNo(),transactionAmount);

//                    3.添加记录
                    TransactionRecord transactionRecord = new TransactionRecord();
                    transactionRecord.setCardNo(sourceAccount.getCardNo());
                    transactionRecord.setTransactionAmount(transactionAmount);
                    transactionRecord.setTransactionType("转账");
                    transactionRecord.setTransactionDate(new Date());
//                    重新查询balance
                    double balance = accountMapper.queryBalance(sourceAccount.getCardNo());
                    transactionRecord.setBalance(balance);

                    transactionMapper.insert(transactionRecord);
                    code = StatusCodeConstent.SUCCESS;
                    msg = StatusCodeConstent.SUCCESS_MSG;
                }else{
//                    余额不足
                    code = StatusCodeConstent.BALANCE_NOT_ENOUGH;
                    msg = StatusCodeConstent.BALANCE_NOT_ENOUGH_MSG;
                }
            }else {
//                冻结
                code = StatusCodeConstent.FREEZON;
                msg = StatusCodeConstent.FREEZON_MSG;
            }
        }else{
//            目标账号不存在
            msg = StatusCodeConstent.NOT_EXISTS_MSG;
        }

//        4.一方加钱成功，一方减钱成功
        map.put("code",code);
        map.put("msg",msg);
        return map;
    }


    /**
     * 校验账户密码
     * @param account
     * @return
     */
    @Override
    public Account pwdCorrect(Account account) {
        Account a =  accountMapper.queryByCardNoPwd(account.getCardNo(), account.getPassword());
        return a;
    }

    /**
     * 修改密码
     * @param account
     * @param newPwd1
     * @return
     */
    @Override
    public int changePwd(Account account, String newPwd1) {
        return accountMapper.changePwd(account.getCardNo(),newPwd1);
    }
}
